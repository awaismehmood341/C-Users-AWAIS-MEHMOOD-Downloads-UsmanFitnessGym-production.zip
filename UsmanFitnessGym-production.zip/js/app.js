
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
document.addEventListener('DOMContentLoaded',()=>{
  setTimeout(()=>document.body.classList.add('loaded'),650);
  $('#year').textContent=new Date().getFullYear();
  $('#nav').classList.toggle('scrolled',scrollY>30);
  addEventListener('scroll',()=>$('#nav').classList.toggle('scrolled',scrollY>30),{passive:true});

  const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.12});
  $$('.reveal').forEach(x=>io.observe(x));

  // Mobile menu
  $('#menuBtn').onclick=()=>$('#nav').classList.toggle('mobile-open');
  $$('.links a').forEach(a=>a.onclick=()=>$('#nav').classList.remove('mobile-open'));

  // Membership registration
  const modal=$('#membershipModal');
  const openMembership=plan=>{
    modal.classList.add('open'); document.body.style.overflow='hidden';
    $('#mPlan').value=plan||'Premium';
    setTimeout(()=>$('#mName').focus(),100);
  };
  $$('[data-membership]').forEach(b=>b.onclick=()=>openMembership(b.dataset.membership));
  $$('[data-close]').forEach(b=>b.onclick=()=>{modal.classList.remove('open');document.body.style.overflow=''});
  modal.onclick=e=>{if(e.target===modal){modal.classList.remove('open');document.body.style.overflow=''}};
  addEventListener('keydown',e=>{if(e.key==='Escape'){modal.classList.remove('open');document.body.style.overflow=''}});

  $('#membershipForm').onsubmit=async e=>{
    e.preventDefault();
    const form=e.target;
    const submitBtn=form.querySelector('button[type=submit]');
    const originalText=submitBtn.textContent;
    const data=Object.fromEntries(new FormData(form));
    const id='UFG-'+Math.random().toString(36).slice(2,7).toUpperCase();
    data.registration_id=id;
    data.source='Usman Fitness Gym website';
    data.submitted_at=new Date().toLocaleString();

    submitBtn.disabled=true;
    submitBtn.textContent='Sending…';

    try{
      const response=await fetch(form.dataset.emailEndpoint,{
        method:'POST',
        headers:{'Content-Type':'application/json','Accept':'application/json'},
        body:JSON.stringify({
          ...data,
          _subject:`New Usman Fitness Gym Membership — ${data.plan} — ${id}`,
          _template:'table',
          _replyto:data.email
        })
      });
      const result=await response.json().catch(()=>({}));
      if(!response.ok || result.success===false) throw new Error(result.message||'Email service rejected the registration.');

      const all=JSON.parse(localStorage.getItem('ufg-members')||'[]');
      all.push({...data,created:new Date().toISOString()});
      localStorage.setItem('ufg-members',JSON.stringify(all));
      $('#membershipForm').hidden=true;
      $('#membershipDone').hidden=false;
      $('#memberRef').textContent=id;
    }catch(error){
      toast('Registration could not be sent. Please try again.');
      console.error('Membership submission failed:',error);
    }finally{
      submitBtn.disabled=false;
      submitBtn.textContent=originalText;
    }
  };
  $('#newMember').onclick=()=>{ $('#membershipForm').reset(); $('#membershipForm').hidden=false; $('#membershipDone').hidden=true; };

  // Product cart / protein stock
  let cart=JSON.parse(localStorage.getItem('ufg-cart')||'[]');
  function toast(t){const el=$('#toast');el.textContent=t;el.classList.add('toast-show');setTimeout(()=>el.classList.remove('toast-show'),2200)}
  function renderCart(){ $('#cartCount').textContent=cart.reduce((a,x)=>a+x.qty,0); }
  $$('.add-product').forEach(b=>b.onclick=()=>{
    const item={name:b.dataset.name,price:+b.dataset.price,qty:1};
    const found=cart.find(x=>x.name===item.name); if(found)found.qty++; else cart.push(item);
    localStorage.setItem('ufg-cart',JSON.stringify(cart));renderCart();toast(item.name+' added to stock order');
  });
  renderCart();

  // BMI calculator
  $('#bmiForm').onsubmit=e=>{
    e.preventDefault(); const w=+$('#weight').value,h=+$('#height').value/100;
    if(!w||!h)return; const bmi=w/(h*h); let label=bmi<18.5?'Underweight':bmi<25?'Healthy range':bmi<30?'Overweight':'Obesity';
    $('#bmiResult').innerHTML=`<strong>BMI ${bmi.toFixed(1)}</strong><br><span>${label}</span>`;
  };

  // Simple workout goal selector
  $$('.goal-btn').forEach(b=>b.onclick=()=>{
    $$('.goal-btn').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');
    const plans={Muscle:'Push/Pull/Legs · 4 days/week · progressive overload',FatLoss:'Full body + cardio · 4 days/week · calorie control',Fitness:'Full body · 3 days/week · mobility + conditioning'};
    $('#goalResult').textContent=plans[b.dataset.goal];
  });

  // Close all modals / start demo
  $('#cartBtn').onclick=()=>toast(`You have ${cart.reduce((a,x)=>a+x.qty,0)} item(s) in your order.`);
});
