# Usman Fitness Gym

A gym website adapted from the uploaded Revamp Auto Hub design.

## Run
Open `index.html` in a browser. No build step is required.

## Included functionality
- Responsive dark/glass gym design
- Gym facilities section
- Protein stock with prices and add-to-order list using localStorage
- Membership plans and registration modal
- Registration reference generation and localStorage persistence
- Gym outfits / equipment shop section
- BMI calculator
- Workout goal planner
- Scroll reveal animations
- Mobile navigation
- Responsive layout

## Production notes
The protein prices, phone number, address, membership prices and product images are demo content. Replace them in `index.html`.
Membership registration is connected to FormSubmit AJAX and sends new registrations to `awaist5558@gmail.com`. The first live submission requires clicking the activation/confirmation link sent by FormSubmit. The browser also keeps a local copy for the site operator.
Product photos currently use remote Unsplash image URLs, so internet access is needed for those pictures.


## Production email setup
The membership form uses FormSubmit as the email backend:
- Endpoint: `https://formsubmit.co/ajax/awaist5558@gmail.com`
- Recipient: `awaist5558@gmail.com`
- The form sends the member name, phone, email, age, plan, fitness goal, notes, registration ID and submission time.
- FormSubmit requires the recipient to confirm/activate the form the first time.
- The site must be served from a web server/hosting environment; opening `index.html` directly from the filesystem is not supported for FormSubmit submissions.
- For higher-control production deployments, replace the endpoint in `index.html` with your own server/API endpoint and keep any SMTP/API secret on the server, never in browser JavaScript.
